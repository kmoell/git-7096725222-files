// Global state
let ws = null;
let localStream = null;
let peerConnection = null;
let dataChannel = null;
let currentUser = null;
let currentRoom = null;
let roomUsers = new Map();
let callInProgress = false;
let currentCallUser = null;

// ICE servers configuration
const iceServers = {
    iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' }
    ]
};

// DOM elements
const joinScreen = document.getElementById('joinScreen');
const roomScreen = document.getElementById('roomScreen');
const nicknameInput = document.getElementById('nicknameInput');
const roomIdInput = document.getElementById('roomIdInput');
const joinButton = document.getElementById('joinButton');
const leaveButton = document.getElementById('leaveButton');
const joinError = document.getElementById('joinError');
const connectionStatus = document.getElementById('connectionStatus');
const usersList = document.getElementById('usersList');
const localVideo = document.getElementById('localVideo');
const remoteVideo = document.getElementById('remoteVideo');
const previewVideo = document.getElementById('previewVideo');
const videoGrid = document.getElementById('videoGrid');
const noCallMessage = document.getElementById('noCallMessage');
const localPreview = document.getElementById('localPreview');
const hangupButton = document.getElementById('hangupButton');
const chatSidebar = document.getElementById('chatSidebar');
const chatMessages = document.getElementById('chatMessages');
const chatInput = document.getElementById('chatInput');
const sendButton = document.getElementById('sendButton');
const remoteLabel = document.getElementById('remoteLabel');

// Event listeners
joinButton.addEventListener('click', joinRoom);
leaveButton.addEventListener('click', leaveRoom);
hangupButton.addEventListener('click', hangup);
sendButton.addEventListener('click', sendChatMessage);
chatInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendChatMessage();
});

// Initialize WebSocket connection
function connectWebSocket() {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    ws = new WebSocket(`${protocol}//${host}`);

    ws.onopen = () => {
        console.log('WebSocket connected');
        updateConnectionStatus(true);
    };

    ws.onclose = () => {
        console.log('WebSocket disconnected');
        updateConnectionStatus(false);
        setTimeout(connectWebSocket, 3000);
    };

    ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        showError('Ошибка подключения к серверу');
    };

    ws.onmessage = handleWebSocketMessage;
}

// Handle WebSocket messages
function handleWebSocketMessage(event) {
    const message = JSON.parse(event.data);
    console.log('Received message:', message);

    switch (message.type) {
        case 'joined':
            handleJoined(message);
            break;
        case 'user-joined':
            handleUserJoined(message);
            break;
        case 'user-left':
            handleUserLeft(message);
            break;
        case 'users-list':
            handleUsersList(message);
            break;
        case 'offer':
            handleOffer(message);
            break;
        case 'answer':
            handleAnswer(message);
            break;
        case 'ice-candidate':
            handleIceCandidate(message);
            break;
        case 'call-ended':
            handleCallEnded(message);
            break;
        case 'error':
            showError(message.message);
            break;
    }
}

// Update connection status
function updateConnectionStatus(connected) {
    if (connected) {
        connectionStatus.textContent = 'Подключено';
        connectionStatus.classList.add('connected');
    } else {
        connectionStatus.textContent = 'Отключено';
        connectionStatus.classList.remove('connected');
    }
}

// Show error message
function showError(message) {
    joinError.textContent = message;
    joinError.classList.add('show');
    setTimeout(() => {
        joinError.classList.remove('show');
    }, 5000);
}

// Join room
async function joinRoom() {
    const nickname = nicknameInput.value.trim();
    const roomId = roomIdInput.value.trim();

    if (!nickname) {
        showError('Введите никнейм');
        return;
    }

    if (!roomId) {
        showError('Введите ID комнаты');
        return;
    }

    try {
        // Request media permissions
        localStream = await navigator.mediaDevices.getUserMedia({
            video: true,
            audio: true
        });

        currentUser = nickname;
        currentRoom = roomId;

        // Set preview video
        previewVideo.srcObject = localStream;
        localPreview.classList.remove('hidden');

        // Send join message
        ws.send(JSON.stringify({
            type: 'join',
            nickname: nickname,
            roomId: roomId
        }));

    } catch (error) {
        console.error('Error accessing media devices:', error);
        showError('Не удалось получить доступ к камере/микрофону');
    }
}

// Handle successful join
function handleJoined(message) {
    joinScreen.style.display = 'none';
    roomScreen.classList.add('active');
    console.log('Successfully joined room:', message.roomId);
}

// Handle users list
function handleUsersList(message) {
    roomUsers.clear();
    message.users.forEach(user => {
        roomUsers.set(user.id, user);
    });
    updateUsersList();
}

// Handle user joined
function handleUserJoined(message) {
    roomUsers.set(message.user.id, message.user);
    updateUsersList();
}

// Handle user left
function handleUserLeft(message) {
    roomUsers.delete(message.userId);
    updateUsersList();
    
    // If we were in a call with this user, end it
    if (currentCallUser === message.userId) {
        hangup();
    }
}

// Update users list UI
function updateUsersList() {
    usersList.innerHTML = '';
    
    roomUsers.forEach((user, userId) => {
        const userItem = document.createElement('div');
        userItem.className = 'user-item';
        
        if (user.nickname === currentUser) {
            userItem.classList.add('self');
        } else {
            userItem.addEventListener('click', () => initiateCall(userId, user.nickname));
        }
        
        userItem.innerHTML = `
            <div class="user-status"></div>
            <div class="user-name">${user.nickname}${user.nickname === currentUser ? ' (Вы)' : ''}</div>
        `;
        
        usersList.appendChild(userItem);
    });
}

// Initiate call to another user
async function initiateCall(userId, username) {
    if (callInProgress) {
        showError('Звонок уже идёт');
        return;
    }

    console.log('Initiating call to:', username);
    currentCallUser = userId;
    callInProgress = true;

    // Create peer connection
    createPeerConnection(userId, username);

    // Add local stream to peer connection
    localStream.getTracks().forEach(track => {
        peerConnection.addTrack(track, localStream);
    });

    // Create data channel for chat
    dataChannel = peerConnection.createDataChannel('chat');
    setupDataChannel();

    // Create and send offer
    try {
        const offer = await peerConnection.createOffer();
        await peerConnection.setLocalDescription(offer);

        ws.send(JSON.stringify({
            type: 'offer',
            offer: offer,
            targetUserId: userId
        }));

        // Show call UI
        showCallUI(username);
    } catch (error) {
        console.error('Error creating offer:', error);
        showError('Не удалось инициировать звонок');
        hangup();
    }
}

// Create peer connection
function createPeerConnection(userId, username) {
    peerConnection = new RTCPeerConnection(iceServers);

    // Handle ICE candidates
    peerConnection.onicecandidate = (event) => {
        if (event.candidate) {
            ws.send(JSON.stringify({
                type: 'ice-candidate',
                candidate: event.candidate,
                targetUserId: userId
            }));
        }
    };

    // Handle remote stream
    peerConnection.ontrack = (event) => {
        console.log('Received remote track');
        if (remoteVideo.srcObject !== event.streams[0]) {
            remoteVideo.srcObject = event.streams[0];
        }
    };

    // Handle connection state changes
    peerConnection.onconnectionstatechange = () => {
        console.log('Connection state:', peerConnection.connectionState);
        if (peerConnection.connectionState === 'failed' || 
            peerConnection.connectionState === 'disconnected') {
            hangup();
        }
    };

    // Handle data channel from remote peer
    peerConnection.ondatachannel = (event) => {
        dataChannel = event.channel;
        setupDataChannel();
    };
}

// Setup data channel for P2P chat
function setupDataChannel() {
    dataChannel.onopen = () => {
        console.log('Data channel opened');
        chatSidebar.classList.add('active');
    };

    dataChannel.onclose = () => {
        console.log('Data channel closed');
        chatSidebar.classList.remove('active');
    };

    dataChannel.onmessage = (event) => {
        const data = JSON.parse(event.data);
        displayChatMessage(data.sender, data.message);
    };
}

// Handle incoming offer
async function handleOffer(message) {
    if (callInProgress) {
        // Already in a call, reject
        ws.send(JSON.stringify({
            type: 'call-ended',
            targetUserId: message.fromUserId
        }));
        return;
    }

    console.log('Received offer from:', message.fromUserId);
    currentCallUser = message.fromUserId;
    callInProgress = true;

    const fromUser = roomUsers.get(message.fromUserId);
    const username = fromUser ? fromUser.nickname : 'Unknown';

    // Create peer connection
    createPeerConnection(message.fromUserId, username);

    // Add local stream to peer connection
    localStream.getTracks().forEach(track => {
        peerConnection.addTrack(track, localStream);
    });

    try {
        await peerConnection.setRemoteDescription(new RTCSessionDescription(message.offer));
        const answer = await peerConnection.createAnswer();
        await peerConnection.setLocalDescription(answer);

        ws.send(JSON.stringify({
            type: 'answer',
            answer: answer,
            targetUserId: message.fromUserId
        }));

        // Show call UI
        showCallUI(username);
    } catch (error) {
        console.error('Error handling offer:', error);
        hangup();
    }
}

// Handle incoming answer
async function handleAnswer(message) {
    try {
        await peerConnection.setRemoteDescription(new RTCSessionDescription(message.answer));
        console.log('Answer set successfully');
    } catch (error) {
        console.error('Error handling answer:', error);
    }
}

// Handle ICE candidate
async function handleIceCandidate(message) {
    try {
        if (peerConnection) {
            await peerConnection.addIceCandidate(new RTCIceCandidate(message.candidate));
        }
    } catch (error) {
        console.error('Error adding ICE candidate:', error);
    }
}

// Handle call ended by remote user
function handleCallEnded(message) {
    if (message.fromUserId === currentCallUser) {
        hangup();
    }
}

// Show call UI
function showCallUI(username) {
    noCallMessage.classList.add('hidden');
    videoGrid.classList.remove('hidden');
    hangupButton.classList.remove('hidden');
    localPreview.classList.add('hidden');
    remoteLabel.textContent = username;
    
    // Set video sources
    localVideo.srcObject = localStream;
}

// Hangup call
function hangup() {
    console.log('Hanging up call');

    // Notify remote user
    if (currentCallUser && ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
            type: 'call-ended',
            targetUserId: currentCallUser
        }));
    }

    // Close peer connection
    if (peerConnection) {
        peerConnection.close();
        peerConnection = null;
    }

    // Close data channel
    if (dataChannel) {
        dataChannel.close();
        dataChannel = null;
    }

    // Clear remote video
    remoteVideo.srcObject = null;
    localVideo.srcObject = null;

    // Reset UI
    videoGrid.classList.add('hidden');
    noCallMessage.classList.remove('hidden');
    hangupButton.classList.add('hidden');
    chatSidebar.classList.remove('active');
    localPreview.classList.remove('hidden');
    chatMessages.innerHTML = '';

    // Reset state
    callInProgress = false;
    currentCallUser = null;
}

// Send chat message
function sendChatMessage() {
    const message = chatInput.value.trim();
    if (!message || !dataChannel || dataChannel.readyState !== 'open') {
        return;
    }

    const data = {
        sender: currentUser,
        message: message
    };

    dataChannel.send(JSON.stringify(data));
    displayChatMessage(currentUser, message);
    chatInput.value = '';
}

// Display chat message
function displayChatMessage(sender, message) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message';
    messageDiv.innerHTML = `
        <div class="message-author">${sender}</div>
        <div class="message-text">${escapeHtml(message)}</div>
    `;
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Leave room
function leaveRoom() {
    // Hangup any active call
    if (callInProgress) {
        hangup();
    }

    // Stop local stream
    if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
        localStream = null;
    }

    // Clear preview
    previewVideo.srcObject = null;
    localPreview.classList.add('hidden');

    // Notify server
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
            type: 'leave'
        }));
    }

    // Reset state
    currentUser = null;
    currentRoom = null;
    roomUsers.clear();

    // Reset UI
    joinScreen.style.display = 'flex';
    roomScreen.classList.remove('active');
    usersList.innerHTML = '';
}

// Initialize app
connectWebSocket();