const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Serve static files
app.use(express.static(__dirname));

// In-memory storage
const rooms = new Map();
const clients = new Map();

// Generate unique ID
function generateId() {
    return Math.random().toString(36).substring(2, 15);
}

// WebSocket connection handler
wss.on('connection', (ws) => {
    const clientId = generateId();
    console.log(`Client connected: ${clientId}`);

    const client = {
        id: clientId,
        ws: ws,
        nickname: null,
        roomId: null
    };

    clients.set(clientId, client);

    ws.on('message', (data) => {
        try {
            const message = JSON.parse(data);
            handleMessage(client, message);
        } catch (error) {
            console.error('Error parsing message:', error);
        }
    });

    ws.on('close', () => {
        console.log(`Client disconnected: ${clientId}`);
        handleDisconnect(client);
        clients.delete(clientId);
    });

    ws.on('error', (error) => {
        console.error('WebSocket error:', error);
    });
});

// Handle incoming messages
function handleMessage(client, message) {
    console.log(`Message from ${client.id}:`, message.type);

    switch (message.type) {
        case 'join':
            handleJoin(client, message);
            break;
        case 'leave':
            handleLeave(client);
            break;
        case 'offer':
            handleOffer(client, message);
            break;
        case 'answer':
            handleAnswer(client, message);
            break;
        case 'ice-candidate':
            handleIceCandidate(client, message);
            break;
        case 'call-ended':
            handleCallEnded(client, message);
            break;
        default:
            console.log('Unknown message type:', message.type);
    }
}

// Handle user joining a room
function handleJoin(client, message) {
    const { nickname, roomId } = message;

    if (!nickname || !roomId) {
        sendError(client, 'Nickname and room ID are required');
        return;
    }

    // Update client info
    client.nickname = nickname;
    client.roomId = roomId;

    // Create room if it doesn't exist
    if (!rooms.has(roomId)) {
        rooms.set(roomId, new Set());
    }

    const room = rooms.get(roomId);
    room.add(client.id);

    // Send success message to client
    client.ws.send(JSON.stringify({
        type: 'joined',
        roomId: roomId,
        userId: client.id
    }));

    // Send current users list to the new client
    const usersList = getUsersList(roomId);
    client.ws.send(JSON.stringify({
        type: 'users-list',
        users: usersList
    }));

    // Notify other users in the room
    broadcastToRoom(roomId, {
        type: 'user-joined',
        user: {
            id: client.id,
            nickname: client.nickname
        }
    }, client.id);

    console.log(`${nickname} joined room ${roomId}`);
}

// Handle user leaving a room
function handleLeave(client) {
    if (client.roomId) {
        const room = rooms.get(client.roomId);
        if (room) {
            room.delete(client.id);

            // Notify other users
            broadcastToRoom(client.roomId, {
                type: 'user-left',
                userId: client.id,
                nickname: client.nickname
            });

            // Delete room if empty
            if (room.size === 0) {
                rooms.delete(client.roomId);
            }
        }

        console.log(`${client.nickname} left room ${client.roomId}`);
        client.roomId = null;
        client.nickname = null;
    }
}

// Handle disconnect
function handleDisconnect(client) {
    handleLeave(client);
}

// Handle WebRTC offer
function handleOffer(client, message) {
    const targetClient = clients.get(message.targetUserId);
    if (targetClient && targetClient.ws.readyState === WebSocket.OPEN) {
        targetClient.ws.send(JSON.stringify({
            type: 'offer',
            offer: message.offer,
            fromUserId: client.id,
            fromNickname: client.nickname
        }));
    }
}

// Handle WebRTC answer
function handleAnswer(client, message) {
    const targetClient = clients.get(message.targetUserId);
    if (targetClient && targetClient.ws.readyState === WebSocket.OPEN) {
        targetClient.ws.send(JSON.stringify({
            type: 'answer',
            answer: message.answer,
            fromUserId: client.id
        }));
    }
}

// Handle ICE candidate
function handleIceCandidate(client, message) {
    const targetClient = clients.get(message.targetUserId);
    if (targetClient && targetClient.ws.readyState === WebSocket.OPEN) {
        targetClient.ws.send(JSON.stringify({
            type: 'ice-candidate',
            candidate: message.candidate,
            fromUserId: client.id
        }));
    }
}

// Handle call ended
function handleCallEnded(client, message) {
    const targetClient = clients.get(message.targetUserId);
    if (targetClient && targetClient.ws.readyState === WebSocket.OPEN) {
        targetClient.ws.send(JSON.stringify({
            type: 'call-ended',
            fromUserId: client.id
        }));
    }
}

// Get list of users in a room
function getUsersList(roomId) {
    const room = rooms.get(roomId);
    if (!room) return [];

    const usersList = [];
    room.forEach(clientId => {
        const client = clients.get(clientId);
        if (client) {
            usersList.push({
                id: client.id,
                nickname: client.nickname
            });
        }
    });

    return usersList;
}

// Broadcast message to all users in a room except sender
function broadcastToRoom(roomId, message, excludeClientId = null) {
    const room = rooms.get(roomId);
    if (!room) return;

    room.forEach(clientId => {
        if (clientId !== excludeClientId) {
            const client = clients.get(clientId);
            if (client && client.ws.readyState === WebSocket.OPEN) {
                client.ws.send(JSON.stringify(message));
            }
        }
    });
}

// Send error to client
function sendError(client, message) {
    if (client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(JSON.stringify({
            type: 'error',
            message: message
        }));
    }
}

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
    console.log(`Open http://localhost:${PORT} in your browser`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM signal received: closing HTTP server');
    server.close(() => {
        console.log('HTTP server closed');
    });
})